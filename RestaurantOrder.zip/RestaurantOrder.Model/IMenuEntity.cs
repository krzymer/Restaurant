﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantOrder.Model
{
    public interface IMenuEntity
    {
        int Id { get; set; }
        string Name { get; set; }
        double Price { get; set; }

        TypeOfMeal? Type { get; set; }
    }
}
